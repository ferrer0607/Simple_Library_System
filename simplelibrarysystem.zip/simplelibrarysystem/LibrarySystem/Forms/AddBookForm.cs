
using System;
using System.Windows.Forms;
using LibrarySystem.Models;

namespace LibrarySystem.Forms
{
    public class AddBookForm : Form
    {
        private TextBox txtId = new TextBox();
        private TextBox txtTitle = new TextBox();
        private Button btnAdd = new Button();

        public AddBookForm()
        {
            Text = "Add Book";
            Width = 300;
            Height = 200;

            Controls.Add(new Label() { Text = "Book ID:", Top = 20, Left = 20 });
            txtId.SetBounds(100, 20, 150, 20);
            Controls.Add(txtId);

            Controls.Add(new Label() { Text = "Title:", Top = 60, Left = 20 });
            txtTitle.SetBounds(100, 60, 150, 20);
            Controls.Add(txtTitle);

            btnAdd.Text = "Add";
            btnAdd.SetBounds(100, 100, 80, 30);
            btnAdd.Click += BtnAdd_Click;
            Controls.Add(btnAdd);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var book = new Book(txtId.Text, txtTitle.Text);
            Program.LibraryService.AddBook(book);
            MessageBox.Show("Book added successfully!");
            Close();
        }
    }
}
