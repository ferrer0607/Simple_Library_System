
using System;
using System.Windows.Forms;
using LibrarySystem.Models;

namespace LibrarySystem.Forms
{
    public class RegisterMemberForm : Form
    {
        private TextBox txtId = new TextBox();
        private TextBox txtName = new TextBox();
        private Button btnRegister = new Button();

        public RegisterMemberForm()
        {
            Text = "Register Member";
            Width = 300;
            Height = 200;

            Controls.Add(new Label() { Text = "Member ID:", Top = 20, Left = 20 });
            txtId.SetBounds(100, 20, 150, 20);
            Controls.Add(txtId);

            Controls.Add(new Label() { Text = "Name:", Top = 60, Left = 20 });
            txtName.SetBounds(100, 60, 150, 20);
            Controls.Add(txtName);

            btnRegister.Text = "Register";
            btnRegister.SetBounds(100, 100, 80, 30);
            btnRegister.Click += BtnRegister_Click;
            Controls.Add(btnRegister);
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            var member = new Member(txtId.Text, txtName.Text);
            Program.LibraryService.RegisterMember(member);
            MessageBox.Show("Member registered successfully!");
            Close();
        }
    }
}
