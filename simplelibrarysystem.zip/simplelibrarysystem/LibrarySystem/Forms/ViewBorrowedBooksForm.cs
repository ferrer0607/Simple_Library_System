
using System;
using System.Windows.Forms;

namespace LibrarySystem.Forms
{
    public class ViewBorrowedBooksForm : Form
    {
        private ListBox listBox = new ListBox();

        public ViewBorrowedBooksForm()
        {
            Text = "Borrowed Books";
            Width = 400;
            Height = 300;

            listBox.Dock = DockStyle.Fill;
            Controls.Add(listBox);

            foreach (var record in Program.LibraryService.GetAllBorrowRecords())
            {
                listBox.Items.Add(record.ToString());
            }
        }
    }
}
