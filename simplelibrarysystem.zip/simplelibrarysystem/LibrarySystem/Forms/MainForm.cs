
using System;
using System.Windows.Forms;

namespace LibrarySystem.Forms
{
    public class MainForm : Form
    {
        public MainForm()
        {
            Text = "Library System - Main Menu";
            Width = 400;
            Height = 300;

            var addBookBtn = new Button { Text = "Add Book", Top = 20, Left = 120, Width = 150 };
            var registerMemberBtn = new Button { Text = "Register Member", Top = 60, Left = 120, Width = 150 };
            var borrowBtn = new Button { Text = "Borrow/Return Book", Top = 100, Left = 120, Width = 150 };
            var viewBorrowedBtn = new Button { Text = "View Borrowed Books", Top = 140, Left = 120, Width = 150 };

            Controls.Add(addBookBtn);
            Controls.Add(registerMemberBtn);
            Controls.Add(borrowBtn);
            Controls.Add(viewBorrowedBtn);

            addBookBtn.Click += (s, e) => new AddBookForm().ShowDialog();
            registerMemberBtn.Click += (s, e) => new RegisterMemberForm().ShowDialog();
            borrowBtn.Click += (s, e) => new BorrowReturnForm().ShowDialog();
            viewBorrowedBtn.Click += (s, e) => new ViewBorrowedBooksForm().ShowDialog();
        }
    }
}
