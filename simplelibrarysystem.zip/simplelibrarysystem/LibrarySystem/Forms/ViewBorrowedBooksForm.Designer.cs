
namespace LibrarySystem.Forms
{
    partial class ViewBorrowedBooksForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "ViewBorrowedBooksForm";
            this.Load += new System.EventHandler(this.ViewBorrowedBooksForm_Load);
            this.ResumeLayout(false);
        }

        private void ViewBorrowedBooksForm_Load(object sender, System.EventArgs e)
        {
        }
    }
}
