
using System;
using System.Windows.Forms;

namespace LibrarySystem.Forms
{
    public class BorrowReturnForm : Form
    {
        private TextBox txtMemberId = new TextBox();
        private TextBox txtBookId = new TextBox();
        private Button btnBorrow = new Button();
        private Button btnReturn = new Button();

        public BorrowReturnForm()
        {
            Text = "Borrow / Return Book";
            Width = 300;
            Height = 220;

            Controls.Add(new Label() { Text = "Member ID:", Top = 20, Left = 20 });
            txtMemberId.SetBounds(100, 20, 150, 20);
            Controls.Add(txtMemberId);

            Controls.Add(new Label() { Text = "Book ID:", Top = 60, Left = 20 });
            txtBookId.SetBounds(100, 60, 150, 20);
            Controls.Add(txtBookId);

            btnBorrow.Text = "Borrow";
            btnBorrow.SetBounds(40, 110, 80, 30);
            btnBorrow.Click += (s, e) =>
            {
                Program.LibraryService.BorrowBook(txtMemberId.Text, txtBookId.Text);
                MessageBox.Show("Book borrowed!");
                Close();
            };
            Controls.Add(btnBorrow);

            btnReturn.Text = "Return";
            btnReturn.SetBounds(160, 110, 80, 30);
            btnReturn.Click += (s, e) =>
            {
                Program.LibraryService.ReturnBook(txtMemberId.Text, txtBookId.Text);
                MessageBox.Show("Book returned!");
                Close();
            };
            Controls.Add(btnReturn);
        }
    }
}
