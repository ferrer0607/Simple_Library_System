
namespace LibrarySystem.Forms
{
    partial class BorrowReturnForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "BorrowReturnForm";
            this.Load += new System.EventHandler(this.BorrowReturnForm_Load);
            this.ResumeLayout(false);
        }

        private void BorrowReturnForm_Load(object sender, System.EventArgs e)
        {
        }
    }
}
