
using System;

namespace LibrarySystem.Models
{
    public class BorrowRecord
    {
        public Member Borrower { get; set; }
        public Book Book { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        public BorrowRecord(Member borrower, Book book)
        {
            Borrower = borrower;
            Book = book;
            BorrowDate = DateTime.Now;
            ReturnDate = null;
        }

        public override string ToString()
        {
            return $"{Borrower.Name} borrowed '{Book.Title}' on {BorrowDate.ToShortDateString()}" +
                   (ReturnDate.HasValue ? $" and returned it on {ReturnDate.Value.ToShortDateString()}" : "");
        }
    }
}
