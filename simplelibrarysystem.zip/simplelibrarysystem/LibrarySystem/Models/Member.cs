
namespace LibrarySystem.Models
{
    public class Member : Person
    {
        public string MemberId { get; set; }

        public Member(string id, string name) : base(name)
        {
            MemberId = id;
        }

        public override string GetDetails()
        {
            return $"{MemberId} - {Name}";
        }
    }
}
