
namespace LibrarySystem.Models
{
    public class Book
    {
        public string BookId { get; set; }
        public string Title { get; set; }
        public bool IsBorrowed { get; set; }

        public Book(string id, string title)
        {
            BookId = id;
            Title = title;
            IsBorrowed = false;
        }

        public override string ToString() => $"{BookId} - {Title}";
    }
}
