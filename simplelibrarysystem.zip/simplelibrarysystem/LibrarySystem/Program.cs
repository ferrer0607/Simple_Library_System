
using System;
using System.Windows.Forms;

namespace LibrarySystem
{
    static class Program
    {
        public static LibraryService LibraryService = new LibraryService();

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Forms.MainForm());
        }
    }
}
