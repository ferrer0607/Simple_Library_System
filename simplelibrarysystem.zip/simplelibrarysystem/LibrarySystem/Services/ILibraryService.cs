
using System.Collections.Generic;
using LibrarySystem.Models;

namespace LibrarySystem.Services
{
    public interface ILibraryService
    {
        void AddBook(Book book);
        void RegisterMember(Member member);
        void BorrowBook(string memberId, string bookId);
        void ReturnBook(string memberId, string bookId);
        List<Book> GetAllBooks();
        List<Member> GetAllMembers();
        List<BorrowRecord> GetAllBorrowRecords();
    }
}
