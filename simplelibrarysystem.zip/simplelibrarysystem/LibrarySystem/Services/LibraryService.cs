
using System.Collections.Generic;
using System.Linq;
using LibrarySystem.Models;

namespace LibrarySystem.Services
{
    public class LibraryService : ILibraryService
    {
        private List<Book> books = new();
        private List<Member> members = new();
        private List<BorrowRecord> borrowRecords = new();

        public void AddBook(Book book) => books.Add(book);
        public void RegisterMember(Member member) => members.Add(member);

        public void BorrowBook(string memberId, string bookId)
        {
            var member = members.FirstOrDefault(m => m.MemberId == memberId);
            var book = books.FirstOrDefault(b => b.BookId == bookId);

            if (member != null && book != null && !book.IsBorrowed)
            {
                book.IsBorrowed = true;
                borrowRecords.Add(new BorrowRecord(member, book));
            }
        }

        public void ReturnBook(string memberId, string bookId)
        {
            var record = borrowRecords
                .Where(r => r.Borrower.MemberId == memberId && r.Book.BookId == bookId && r.ReturnDate == null)
                .FirstOrDefault();

            if (record != null)
            {
                record.ReturnDate = System.DateTime.Now;
                record.Book.IsBorrowed = false;
            }
        }

        public List<Book> GetAllBooks() => books;
        public List<Member> GetAllMembers() => members;
        public List<BorrowRecord> GetAllBorrowRecords() => borrowRecords;
    }
}
